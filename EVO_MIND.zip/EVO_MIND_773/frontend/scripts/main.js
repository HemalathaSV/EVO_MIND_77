import ApiService from "../services/apiService.js";

// ===============================
// DOM ELEMENTS
// ===============================
const tournamentList = document.getElementById("tournamentList");
const addTournamentBtn = document.getElementById("addTournamentBtn");
const modal = document.getElementById("tournamentModal");
const closeModalBtn = document.getElementById("closeModalBtn");
const tournamentForm = document.getElementById("tournamentForm");
const modalTitle = document.getElementById("modalTitle");

let editTournamentId = "";

// ===============================
// INITIALIZE
// ===============================
document.addEventListener("DOMContentLoaded", loadTournaments);

// ===============================
// FETCH AND RENDER TOURNAMENTS
// ===============================
async function loadTournaments() {
  try {
    const tournaments = await ApiService.get("/tournaments/");
    renderTournaments(tournaments);
  } catch (error) {
    console.error("Error fetching tournaments:", error);
    tournamentList.innerHTML = `<p class="error-text">Failed to load tournaments.</p>`;
  }
}

function renderTournaments(tournaments = []) {
  if (!tournaments.length) {
    tournamentList.innerHTML = `<p>No tournaments found. Add a new one!</p>`;
    return;
  }

  tournamentList.innerHTML = tournaments
    .map(
      (t) => `
      <div class="tournament-card">
        <div class="tournament-info">
          <h3>${escapeHtml(t.name)} (${escapeHtml(t.sport_type)})</h3>
          <p><strong>Location:</strong> ${escapeHtml(t.location)}</p>
          <p><strong>Start Date:</strong> ${escapeHtml(t.start_date)}</p>
          <p><strong>End Date:</strong> ${escapeHtml(t.end_date)}</p>
        </div>
        <div class="tournament-actions">
          <button
            class="btn-edit"
            data-action="edit"
            data-id="${t.id}"
            data-name="${escapeAttr(t.name)}"
            data-sport_type="${escapeAttr(t.sport_type)}"
            data-location="${escapeAttr(t.location)}"
            data-start_date="${escapeAttr(t.start_date)}"
            data-end_date="${escapeAttr(t.end_date)}"
          >
            <i class="fa-solid fa-pen"></i>
          </button>
          <button class="btn-delete" data-action="delete" data-id="${t.id}">
            <i class="fa-solid fa-trash"></i>
          </button>
        </div>
      </div>
    `
    )
    .join("");
}

// ===============================
// MODAL HANDLERS
// ===============================
addTournamentBtn.addEventListener("click", () => openModal());
closeModalBtn.addEventListener("click", closeModal);
window.addEventListener("click", (e) => e.target === modal && closeModal());

function openModal(tournament = null) {
  modal.style.display = "flex";
  if (tournament) {
    modalTitle.textContent = "Edit Tournament";
    tournamentForm.name.value = tournament.name;
    tournamentForm.sport_type.value = tournament.sport_type;
    tournamentForm.location.value = tournament.location;
    tournamentForm.start_date.value = tournament.start_date;
    tournamentForm.end_date.value = tournament.end_date;
  } else {
    modalTitle.textContent = "Add New Tournament";
    tournamentForm.reset();
  }
}

function closeModal() {
  modal.style.display = "none";
  editTournamentId = null;
}

// ===============================
// FORM SUBMISSION
// ===============================
tournamentForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const tournamentData = {
    name: tournamentForm.name.value,
    sport_type: tournamentForm.sport_type.value,
    location: tournamentForm.location.value,
    start_date: tournamentForm.start_date.value,
    end_date: tournamentForm.end_date.value,
  };

  try {
    if (editTournamentId) {
      await ApiService.put(`/tournaments/${editTournamentId}`, tournamentData);
    } else {
      await ApiService.post("/tournaments/", tournamentData);
    }
    closeModal();
    loadTournaments();
  } catch (error) {
    console.error("Error saving tournament:", error);
  }
});

// ===============================
// EDIT / DELETE HANDLERS
// ===============================
tournamentList.addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-action]");
  if (!btn) return;

  const { action, id } = btn.dataset;

  if (action === "edit") {
    const data = {
      name: btn.dataset.name,
      sport_type: btn.dataset.sport_type,
      location: btn.dataset.location,
      start_date: btn.dataset.start_date,
      end_date: btn.dataset.end_date,
    };
    editTournament(id, data);
  } else if (action === "delete") {
    deleteTournament(id);
  }
});

async function editTournament(id, data) {
  editTournamentId = id;
  openModal(data);
}

async function deleteTournament(id) {
  try {
    await ApiService.delete(`/tournaments/${id}`);
    loadTournaments();
  } catch (error) {
    console.error("Error deleting tournament:", error);
  }
}

// ===============================
// UTILITY FUNCTIONS
// ===============================
function escapeHtml(str = "") {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

function escapeAttr(str = "") {
  return String(str).replaceAll('"', "&quot;");
}
