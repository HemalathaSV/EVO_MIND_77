from core.sqlite_db import db
from models.data_model import Tournament

class TournamentRepo:

   
    def create(tournament: Tournament):
        query = """
            INSERT INTO tournaments (name, sport_type, location, start_date, end_date)
            VALUES (?, ?, ?, ?, ?)
        """
        new_id = db.execute(query, (
            tournament.name,
            tournament.sport_type,
            tournament.location,
            tournament.start_date.isoformat(),
            tournament.end_date.isoformat()
        ))
        return new_id


    def get_all():
        return db.fetch_all("SELECT * FROM tournaments")


    def get_by_id(tournament_id: int):
        return db.fetch_one("SELECT * FROM tournaments WHERE id = ?", (tournament_id,))


    def update(tournament_id: int, data: dict):
        """Dynamically update tournament fields."""
        fields = ", ".join([f"{key} = ?" for key in data.keys()])
        values = list(data.values()) + [tournament_id]
        query = f"UPDATE tournaments SET {fields} WHERE id = ?"
        db.execute(query, tuple(values))


    def delete(tournament_id: int):
        db.execute("DELETE FROM tournaments WHERE id = ?", (tournament_id,))
