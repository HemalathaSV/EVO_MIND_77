from typing import List, Optional
from models.data_model import Organizer


class OrganizerRepo:
    """Repository layer for Organizer model."""
    
    organizers: List[Organizer] = []

    @classmethod
    def create(cls, organizer: Organizer):
        cls.organizers.append(organizer)
        return organizer.organizer_id

    @classmethod
    def get_all(cls) -> List[Organizer]:
        return cls.organizers

    @classmethod
    def get_by_id(cls, organizer_id: int) -> Optional[Organizer]:
        for organizer in cls.organizers:
            if organizer.organizer_id == organizer_id:
                return organizer
        return None

    @classmethod
    def update(cls, organizer_id: int, data: dict) -> Optional[Organizer]:
        organizer = cls.get_by_id(organizer_id)
        if not organizer:
            return None
        for key, value in data.items():
            setattr(organizer, key, value)
        return organizer

    @classmethod
    def delete(cls, organizer_id: int) -> bool:
        for organizer in cls.organizers:
            if organizer.organizer_id == organizer_id:
                cls.organizers.remove(organizer)
                return True
        return False
