import json
import ast
from services import tournament_service
from services import organizer_service

def get_all_tournaments() ->  dict:
    return tournament_service.list_tournaments()
def create_tournaments(data: dict) ->  dict:
    return tournament_service.create_tournament(data)
def delete_tournaments(tournament_id: str) ->  dict:
    return tournament_service.delete_tournament(tournament_id)
def update_tournaments(tournament_id: str,data: dict) ->  dict:
    return tournament_service.update_tournament(tournament_id,data)
def get_last_updated_tournament() -> dict:
    return tournament_service.get_last_updated_tournament()
def get_all_organizers() -> dict:
    return organizer_service.list_organizers()



def create_organizer(data: dict) -> dict:
    return organizer_service.create_organizer(data)

def list_organizers() -> dict:
    return organizer_service.list_organizers()

def get_organizer(organizer_id: int) -> dict:
    return organizer_service.get_organizer(organizer_id)

def update_organizer(organizer_id: int, data: dict) -> dict:
    return organizer_service.update_organizer(organizer_id, data)

def delete_organizer(organizer_id: int) -> dict:
    return organizer_service.delete_organizer(organizer_id)
