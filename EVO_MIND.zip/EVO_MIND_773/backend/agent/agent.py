import asyncio
asyncio.set_event_loop_policy(asyncio.DefaultEventLoopPolicy())
from google.adk.agents import LlmAgent
from agent.tools import *
from agent.prompt import *

Model = "gemini-2.0-flash"
root_agent=LlmAgent(
    name="Tournament_managing_agent",
    model = Model,
    description="Tournament managing agent, corporates and enterprises can converse naturally with AI Agent to eliminate the tedious manual process of tracking inventory and reporting it for audit compliance.", 
    instruction=ROOT_AGENT_PROMPT,
    tools=[
    get_all_tournaments,
    create_tournaments,
    delete_tournaments,
    update_tournaments,
    get_last_updated_tournament,
    create_organizer,
    list_organizers,
    get_organizer,
    update_organizer,
    delete_organizer
]
)