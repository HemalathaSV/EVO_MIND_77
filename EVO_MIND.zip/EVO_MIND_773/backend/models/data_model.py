from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional


class Tournament(BaseModel):
    
    id: Optional[int] = None
    name: str
    sport_type: str
    location: str
    start_date: datetime = Field(default_factory=datetime.utcnow)
    end_date: datetime = Field(default_factory=datetime.utcnow)

    created_at: datetime = Field(default_factory=datetime.utcnow)
    last_updated: datetime = Field(default_factory=datetime.utcnow)
    organizer_id: Optional[int] = None

def touch(self):
    """Refresh the 'last_updated' timestamp when the tournament is modified."""
    self.last_updated = datetime.utcnow()
from pydantic import BaseModel
from typing import Optional
from datetime import date

class Organizer(BaseModel):
    organizer_id: int
    name: str
    region: str
    contact: str


