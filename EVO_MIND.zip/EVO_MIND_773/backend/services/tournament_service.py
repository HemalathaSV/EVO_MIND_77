from datetime import datetime
from models.data_model import Tournament
from repos.tournament_repo import TournamentRepo


def create_tournament(data: dict):
    """Create new tournament with safe defaults for dates."""
    start_date_str = data.get("start_date")
    end_date_str = data.get("end_date")

    start_date = datetime.fromisoformat(start_date_str) if start_date_str else datetime.utcnow()
    end_date = datetime.fromisoformat(end_date_str) if end_date_str else datetime.utcnow()

    tournament = Tournament(
        name=data["name"],
        sport_type=data["sport_type"],
        location=data["location"],
        start_date=start_date,
        end_date=end_date,
    )

    new_id = TournamentRepo.create(tournament)
    return TournamentRepo.get_by_id(new_id)


def list_tournaments():
    """List all tournaments."""
    return TournamentRepo.get_all()


def get_tournament(tournament_id: int):
    """Fetch tournament by ID."""
    tournament = TournamentRepo.get_by_id(tournament_id)
    if not tournament:
        raise ValueError("Tournament not found")
    return tournament


def update_tournament(tournament_id: int, data: dict):
    """Update existing tournament."""
    existing = TournamentRepo.get_by_id(tournament_id)
    if not existing:
        raise ValueError("Tournament not found")

    # Convert date fields if present
    if "start_date" in data:
        data["start_date"] = datetime.fromisoformat(data["start_date"]).isoformat()
    if "end_date" in data:
        data["end_date"] = datetime.fromisoformat(data["end_date"]).isoformat()

    TournamentRepo.update(tournament_id, data)

    # ✅ Return updated object (you missed this in your version)
    return TournamentRepo.get_by_id(tournament_id)


def delete_tournament(tournament_id: int):
    """Delete tournament."""
    existing = TournamentRepo.get_by_id(tournament_id)
    if not existing:
        raise ValueError("Tournament not found")

    TournamentRepo.delete(tournament_id)
    return {"message": f"Tournament {tournament_id} deleted successfully."}


def get_last_updated_tournament():
    """Return the most recently updated tournament."""
    tournaments = TournamentRepo.get_all()
    if not tournaments:
        return {"message": "No tournaments found."}

    latest = max(
        tournaments,
        key=lambda t: t.get("last_updated", t.get("created_at", ""))
    )

    return {
        "name": latest.get("name"),
        "last_updated": latest.get("last_updated"),
        "location": latest.get("location"),
    }
