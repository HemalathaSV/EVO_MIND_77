from models.data_model import Organizer
from repos.organizer_repo import OrganizerRepo


def create_organizer(data: dict):
    """Create a new organizer."""
    organizer = Organizer(**data)
    organizer_id = OrganizerRepo.create(organizer)
    return OrganizerRepo.get_by_id(organizer_id)


def list_organizers():
    """List all organizers."""
    return OrganizerRepo.get_all()


def get_organizer(organizer_id: int):
    """Fetch organizer by ID."""
    return OrganizerRepo.get_by_id(organizer_id)


def update_organizer(organizer_id: int, data: dict):
    """Update existing organizer."""
    existing = OrganizerRepo.get_by_id(organizer_id)
    if not existing:
        raise ValueError("Organizer not found")

    OrganizerRepo.update(organizer_id, data)
    return OrganizerRepo.get_by_id(organizer_id)


def delete_organizer(organizer_id: int):
    """Delete organizer."""
    existing = OrganizerRepo.get_by_id(organizer_id)
    if not existing:
        raise ValueError("Organizer not found")

    OrganizerRepo.delete(organizer_id)
    return {"message": f"Organizer {organizer_id} deleted successfully."}
