import sqlite3

class SQLiteDB:
    """Simple SQLite helper for Tournament Management."""

    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_tables()

    def connect(self):
        """Create a connection with foreign key support."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        return conn

    def _init_tables(self):
        """Create tournaments table if it doesn't exist."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS tournaments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    sport_type TEXT NOT NULL,
                    location TEXT NOT NULL,
                    start_date TEXT NOT NULL,
                    end_date TEXT NOT NULL
                );
            """)
            conn.commit()

    def execute(self, query: str, params: tuple = ()):
        """Run INSERT, UPDATE, DELETE SQL commands."""
        with self.connect() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            conn.commit()
            return cursor.lastrowid

    def fetch_all(self, query: str, params: tuple = ()):
        """Fetch multiple rows as list of dicts."""
        with self.connect() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            rows = cursor.fetchall()
            return [dict(row) for row in rows]

    def fetch_one(self, query: str, params: tuple = ()):
        """Fetch a single row as a dict."""
        with self.connect() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            row = cursor.fetchone()
            return dict(row) if row else None


# ✅ Create DB instance for reuse across app
db = SQLiteDB("tournaments.db")
