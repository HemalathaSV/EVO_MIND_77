from core.sqlite_db import SQLiteDB
import sqlite3
memory_db=SQLiteDB("tournaments.db")