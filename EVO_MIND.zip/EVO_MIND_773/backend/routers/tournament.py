from fastapi import APIRouter, HTTPException
from services import tournament_service

router = APIRouter()


@router.post("/")
def create_tournament(data: dict):
    """Create a new tournament."""
    try:
        return tournament_service.create_tournament(data)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/")
def list_tournaments():
    """List all tournaments."""
    return tournament_service.list_tournaments()


@router.get("/{tournament_id}")
def get_tournament(tournament_id: int):
    """Get a tournament by ID."""
    tournament = tournament_service.get_tournament(tournament_id)
    if not tournament:
        raise HTTPException(status_code=404, detail="Tournament not found")
    return tournament


@router.put("/{tournament_id}")
def update_tournament(tournament_id: int, data: dict):
    """Update an existing tournament."""
    try:
        return tournament_service.update_tournament(tournament_id, data)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.delete("/{tournament_id}")
def delete_tournament(tournament_id: int):
    """Delete a tournament."""
    try:
        return tournament_service.delete_tournament(tournament_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
@staticmethod
def update(tournament_id: int, data: dict):
    for t in TournamentRepo._tournaments:
        if t["id"] == tournament_id:
            t.update(data) 
            return True
    return False
